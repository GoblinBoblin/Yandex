import datetime
from flask import Flask, render_template, redirect
from data.db_session import global_init, create_session
from data.users import User
from data.register_form import RegisterForm
from werkzeug.security import generate_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'mars_secret_key'


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        session = create_session()
        if session.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Такой пользователь уже зарегистрирован")

        user = User(
            email=form.email.data,
            surname=form.surname.data,
            name=form.name.data,
            age=form.age.data,
            position=form.position.data,
            speciality=form.speciality.data,
            address=form.address.data,
            hashed_password=generate_password_hash(form.password.data),
            modified_date=datetime.datetime.now()
        )
        session.add(user)
        session.commit()
        return redirect('/')

    return render_template('register.html', title='Регистрация', form=form)


if __name__ == '__main__':
    global_init("db/mars_mission.db")
    app.run(port=5000, host='127.0.0.1')
